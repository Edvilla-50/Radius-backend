## 6.4.2

* Updates pigeon dev_dependency to ^27.3.2 for analyzer 14 compatibility.

## 6.4.1

* Updates example app to current APIs.

## 6.4.0

* Improves compatibility with `UIScene`.
* Updates minimum supported SDK version to Flutter 3.38/Dart 3.10.

## 6.3.6

* Updates to Pigeon 26.

## 6.3.5

* Updates minimum supported version to iOS 13.
* Updates minimum supported SDK version to Flutter 3.35/Dart 3.9.
* Fixes integration test button text matcher to work on iOS 26.

## 6.3.4

* Updates to Pigeon 25.5.0.
* Updates minimum supported SDK version to Flutter 3.27/Dart 3.6.

## 6.3.3

* Updates minimum supported SDK version to Flutter 3.22/Dart 3.4.
* Ensures the completion callback is invoked if the user dismisses the Safari view before the initial URL load completes.

## 6.3.2

* Updates to Pigeon v22.
* Updates minimum supported SDK version to Flutter 3.19/Dart 3.3.

## 6.3.1

* Fixes a compile error when comforming UIApplication to Launcher in iOS 18 Beta 3.

## 6.3.0

* Adds Swift Package Manager compatibility.

## 6.2.5

* Adds explicit imports for UIKit.
* Updates minimum iOS version to 12.0 and minimum Flutter version to 3.16.6.

## 6.2.4

* Adds privacy manifest.

## 6.2.3

* Updates minimum required plugin_platform_interface version to 2.1.7.

## 6.2.2

* Updates minimum supported SDK version to Flutter 3.10/Dart 3.0.
* Fixes lint warnings.

## 6.2.1

* Migrates plugin from Objective-C to Swift.

## 6.2.0

* Implements `supportsMode` and `supportsCloseForMode`.

## 6.1.5

* Adds pub topics to package metadata.
* Updates minimum supported SDK version to Flutter 3.7/Dart 2.19.

## 6.1.4

* Updates pigeon to fix warnings with clang 15.

## 6.1.3

* Switches to Pigeon for internal implementation.

## 6.1.2

* Clarifies explanation of endorsement in README.

## 6.1.1

* Updates links for the merge of flutter/plugins into flutter/packages.

## 6.1.0

* Updates minimum Flutter version to 3.3 and iOS 11.

## 6.0.18

* Updates code for stricter lint checks.
* Updates minimum Flutter version to 2.10.

## 6.0.17

* Suppresses warnings for pre-iOS-13 codepaths.

## 6.0.16

* Fixes library_private_types_in_public_api, sort_child_properties_last and use_key_in_widget_constructors
  lint warnings.

## 6.0.15

* Switches to an in-package method channel implementation.

## 6.0.14

* Updates code for new analysis options.
* Removes dependency on `meta`.

## 6.0.13

* Splits from `url_launcher` as a federated implementation.
